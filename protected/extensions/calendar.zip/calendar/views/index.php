<div id='fullcalendar'></div>
<script>
$(document).ready(function() {
	$('#fullcalendar').fullCalendar({
		events: [
<?php foreach ($events as $data): ?>
						{
			         	id: '<?php echo $data['id']; ?>',
								title : '<?php echo $data['title']; ?>',
		            content : '<?php echo CHtml::tag('small', array(), $data['content']); ?>',
		            start  : '<?php echo $data['start']; ?>',
		            end  : '<?php echo $data['end']; ?>',
		            href  : '<?php echo $data['href']; ?>',
		            color  : '<?php echo $data['color']; ?>'
		         },
<?php endforeach; ?>		         
		     ],
		eventClick : function(event) {
			send(event.id, event.href);
		},		     
	});
});
</script>
